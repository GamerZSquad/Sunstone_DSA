#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter the value of N: ";
    cin >> n;
    cout << n * (n + 1) / 2;
    return 0;
}
