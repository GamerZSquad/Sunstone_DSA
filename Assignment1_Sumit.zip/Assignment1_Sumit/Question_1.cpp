#include <iostream>
using namespace std;

int main() {
    int a, b;
    int sum;
    
    cout << "Enter two numbers: ";
    cin >> a >> b;
    
    sum = a + b;
    cout << "Sum:" << sum << endl;
    
    return 0;
}
