#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter the value of N: ";
    cin >> n;
    
    for (int i = 1; i <= n; i++) {
        cout << i << endl;
    }
    cout << endl;
    
    return 0;
}
