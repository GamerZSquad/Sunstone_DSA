#include <iostream>
using namespace std;

int main() {
    int n = 7;
    
    for (int i = 1; i <= 10; i++) {
        cout << n * i << endl;
    }
    
    return 0;
}
